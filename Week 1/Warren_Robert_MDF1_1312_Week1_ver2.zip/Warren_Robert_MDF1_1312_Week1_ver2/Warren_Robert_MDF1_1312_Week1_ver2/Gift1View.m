//
//  Gift1View.m
//  Warren_Robert_MDF1_1312_Week1
//
//  Created by Robert Warren on 11/26/13.
//  Copyright (c) 2013 Robert Warren. All rights reserved.
//

#import "Gift1View.h"

@implementation Gift1View

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
