//
//  GiftData.h
//  Warren_Robert_MDF1_1312_Week1_ver2
//
//  Created by Robert Warren on 11/28/13.
//  Copyright (c) 2013 Robert Warren. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GiftData : UIViewController <UITextViewDelegate>
{
   
}
//promary properties
@property (strong, nonatomic) UIImage *insertImage;
@property (strong, nonatomic) NSString *insertName;
@property (strong, nonatomic) NSString *InsertInfo;


@end
