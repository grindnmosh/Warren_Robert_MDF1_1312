//
//  Gift1View.h
//  Warren_Robert_MDF1_1312_Week1
//
//  Created by Robert Warren on 11/26/13.
//  Copyright (c) 2013 Robert Warren. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Gift1View : UITableViewCell
{
    //Custom table view cell Properties
    @public
    IBOutlet UIImageView *santa;
    IBOutlet UILabel *gift;
    IBOutlet UILabel *descrip1;
    IBOutlet UILabel *descrip2;
}
@end
